package com.example.testandofragscommapa.ui.notifications;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.testandofragscommapa.R;

public class NotificationsFragment extends Fragment {

    private NotificationsViewModel notificationsViewModel;
    public EditText login;
    private EditText pass;
    private Button enviar;



    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        notificationsViewModel =
                ViewModelProviders.of(this).get(NotificationsViewModel.class);
        View root = inflater.inflate(R.layout.fragment_notifications, container, false);



        login = root.findViewById(R.id.editText_Usuario);
        pass = root.findViewById(R.id.editText_Senha);
        enviar = root.findViewById(R.id.button_entrar);

        enviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RequestQueue filaEnviadoraDeMensagens = Volley.newRequestQueue(getContext());

                String urlServidor = "http://192.168.31.17/MEI/EfetuarLogin.php";

                urlServidor = urlServidor + "?login="+login.getText().toString();
                urlServidor = urlServidor + "&pass="+pass.getText().toString();
                Log.d("TAG_AAAA",
                        "   "+urlServidor);

                StringRequest requisicao = new StringRequest(
                        Request.Method.GET, // 1 - Método usado para enviar mensagem
                        urlServidor,        // 2 - Endereço do servidor
                        new Response.Listener<String>() { // 3 - Objeto para tratar resposta
                            @Override
                            public void onResponse(String response) {

                                Log.e("TAG_EXEMPLO",
                                        "   "+response);
                                String id  = response;
                                // exibe o resultado na tela usando Toast
                                Toast.makeText(
                                        getContext(),
                                        "id = "+response,
                                        Toast.LENGTH_LONG).show();

                                
                            }


                        },
                        new Response.ErrorListener() { // 4 - Objeto para tratar erro
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                // exibe o erro na tela e nos Logs
                                Toast.makeText(
                                        getContext(),
                                        "Erro: "+error,
                                        Toast.LENGTH_LONG).show();
                                // log de erro no LogCat
                                Log.e("TAG_EXEMPLO",
                                        "Erro encontrado ao tentar enviar mensagem",error);
                            }
                        });


        // envia a mensagem ao servidor
                filaEnviadoraDeMensagens.add(requisicao);
            }
        });
        return root;
    }




}