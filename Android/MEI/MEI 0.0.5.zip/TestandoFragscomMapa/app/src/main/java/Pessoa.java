public class Pessoa {
    private String nome;
    private String email;
    private String senha;
    private Chave chave;
        Pessoa(String nome, String email, String senha){
            this.nome = nome;
            this.email = email;
            this.senha = senha;

        }
}
