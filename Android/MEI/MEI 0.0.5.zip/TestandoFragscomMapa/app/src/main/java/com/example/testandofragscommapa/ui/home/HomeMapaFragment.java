package com.example.testandofragscommapa.ui.home;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import com.example.testandofragscommapa.R;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Polygon;
import com.google.android.gms.maps.model.PolygonOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

public class HomeMapaFragment extends Fragment {

    private HomeViewModel homeViewModel;
    private GoogleMap mMap;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        homeViewModel =
                ViewModelProviders.of(this).get(HomeViewModel.class);

        View root = inflater.inflate(R.layout.fragment_home, container, false);




        // eu coloquei
        //MapView mapa = root.findViewById(R.id.map);
        SupportMapFragment mapa = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map);

        mapa.getMapAsync(new OnMapReadyCallback() {
            @Override
            public void onMapReady(GoogleMap googleMap) {
                mMap = googleMap;

                // Add a marker in Sydney and move the camera

                LatLng ifsul = new LatLng(-29.964225, -51.624498);

                mMap.moveCamera(CameraUpdateFactory.newLatLng(ifsul));
                CameraUpdate location = CameraUpdateFactory.newLatLngZoom(ifsul,20);
                CameraUpdate zoom = CameraUpdateFactory.zoomTo(18);

                PolygonOptions bloco_17 = new PolygonOptions()
                        .add(
                                new LatLng(-29.964782, -51.624442),
                                new LatLng(-29.964878, -51.624442),
                                new LatLng(-29.964879, -51.624380),
                                new LatLng(-29.965049, -51.624187),
                                new LatLng(-29.964936, -51.624054),
                                new LatLng(-29.964762, -51.624240),
                                new LatLng(-29.964708, -51.624245),
                                new LatLng(-29.964709, -51.624353),
                                new LatLng(-29.964767, -51.624351),
                                new LatLng(-29.964784, -51.624369)
                        );

                PolygonOptions bloco_sala_artes = new PolygonOptions()
                        .add(

                                new LatLng(-29.964380, -51.624386),
                                new LatLng(-29.964404, -51.624386),
                                new LatLng(-29.964404, -51.624340),
                                new LatLng(-29.964438, -51.624340),
                                new LatLng(-29.964438, -51.624269),
                                new LatLng(-29.964404, -51.624269),
                                new LatLng(-29.964404, -51.624201),
                                new LatLng(-29.964434, -51.624201),
                                new LatLng(-29.964434, -51.624139),
                                new LatLng(-29.964240, -51.624139),
                                new LatLng(-29.964240, -51.624204),
                                new LatLng(-29.964265, -51.624204),
                                new LatLng(-29.964265, -51.624269),
                                new LatLng(-29.964240, -51.624269),
                                new LatLng(-29.964240, -51.624340),
                                new LatLng(-29.964262, -51.624340),
                                new LatLng(-29.964262, -51.624380),
                                new LatLng(-29.964287, -51.624380),
                                new LatLng(-29.964287, -51.624415),
                                new LatLng(-29.964380, -51.624415)
                        );

                PolygonOptions almoxarifado_eletronica = new PolygonOptions()
                        .add(
                                new LatLng(-29.964349, -51.624190),
                                new LatLng(-29.964349, -51.624139),
                                new LatLng(-29.964318, -51.624139),
                                new LatLng(-29.964318, -51.624190)
                        );

                PolygonOptions lab_eletricidade_nsei = new PolygonOptions()
                        .add(
                                new LatLng(-29.964349, -51.624201),
                                new LatLng(-29.964434, -51.624201),
                                new LatLng(-29.964434, -51.624139),
                                new LatLng(-29.964349, -51.624139)
                        );

                PolygonOptions bMasculino_bloco8 = new PolygonOptions()
                        .add(
                                new LatLng(-29.964349, -51.624234),
                                new LatLng(-29.964404, -51.624234),
                                new LatLng(-29.964404, -51.624201),
                                new LatLng(-29.964349, -51.624201)
                        );

                PolygonOptions bFeminino_bloco8 = new PolygonOptions()
                        .add(
                                new LatLng(-29.964349, -51.624269),
                                new LatLng(-29.964404, -51.624269),
                                new LatLng(-29.964404, -51.624234),
                                new LatLng(-29.964349, -51.624234)
                        );

                PolygonOptions miniAuditorio = new PolygonOptions()
                        .add(
                                new LatLng(-29.964349, -51.624340),
                                new LatLng(-29.964438, -51.624340),
                                new LatLng(-29.964438, -51.624269),
                                new LatLng(-29.964349, -51.624269)
                        );

                PolygonOptions eletronica = new PolygonOptions()
                        .add(
                                new LatLng(-29.964349, -51.624386),
                                new LatLng(-29.964404, -51.624386),
                                new LatLng(-29.964404, -51.624340),
                                new LatLng(-29.964349, -51.624340)
                        );

                PolygonOptions lab_informatica_CAD2 = new PolygonOptions()
                        .add(
                                new LatLng(-29.964318, -51.624204),
                                new LatLng(-29.964240, -51.624204),
                                new LatLng(-29.964240, -51.624139),
                                new LatLng(-29.964318, -51.624139)
                        );

                PolygonOptions lab_informatica_CAD = new PolygonOptions()
                        .add(
                                new LatLng(-29.964318, -51.624269),
                                new LatLng(-29.964265, -51.624269),
                                new LatLng(-29.964265, -51.624204),
                                new LatLng(-29.964318, -51.624204)
                        );

                PolygonOptions sala_artes = new PolygonOptions()
                        .add(
                                new LatLng(-29.964318, -51.624340),
                                new LatLng(-29.964240, -51.624340),
                                new LatLng(-29.964240, -51.624269),
                                new LatLng(-29.964318, -51.624269)
                        );

                PolygonOptions lab_eletricidade_1 = new PolygonOptions()
                        .add(
                                new LatLng(-29.964318, -51.624380),
                                new LatLng(-29.964262, -51.624380),
                                new LatLng(-29.964262, -51.624340),
                                new LatLng(-29.964318, -51.624340)
                        );

                PolygonOptions gremio = new PolygonOptions()
                        .add(
                                new LatLng(-29.964287, -51.624415),
                                new LatLng(-29.964318, -51.624415),
                                new LatLng(-29.964318, -51.624380),
                                new LatLng(-29.964287, -51.624380)
                        );

                PolygonOptions bloco_10 = new PolygonOptions()
                        .add(
                                new LatLng(-29.964619, -51.624435),
                                new LatLng(-29.964619, -51.624090),
                                new LatLng(-29.964524, -51.624090),
                                new LatLng(-29.964524, -51.624435)
                        );

                PolygonOptions sala_1 = new PolygonOptions()
                        .add(
                                new LatLng(-29.964619, -51.624435),
                                new LatLng(-29.964550, -51.624435),
                                new LatLng(-29.964550, -51.624366),
                                new LatLng(-29.964619, -51.624366)
                        );

                PolygonOptions sala_2 = new PolygonOptions()
                        .add(
                                new LatLng(-29.964550, -51.624366),
                                new LatLng(-29.964619, -51.624366),
                                new LatLng(-29.964619, -51.624297),
                                new LatLng(-29.964550, -51.624297)
                        );

                PolygonOptions sala_3 = new PolygonOptions()
                        .add(
                                new LatLng(-29.964619, -51.624297),
                                new LatLng(-29.964550, -51.624297),
                                new LatLng(-29.964550, -51.624228),
                                new LatLng(-29.964619, -51.624228)
                        );

                PolygonOptions sala_4 = new PolygonOptions()
                        .add(
                                new LatLng(-29.964550, -51.624228),
                                new LatLng(-29.964619, -51.624228),
                                new LatLng(-29.964619, -51.624159),
                                new LatLng(-29.964550, -51.624159)
                        );

                PolygonOptions sala_5 = new PolygonOptions()
                        .add(
                                new LatLng(-29.964619, -51.624159),
                                new LatLng(-29.964550, -51.624159),
                                new LatLng(-29.964550, -51.624090),
                                new LatLng(-29.964619, -51.624090)
                        );

                PolygonOptions auditorio = new PolygonOptions()
                        .add(
                                new LatLng(-29.964464, -51.624919),
                                new LatLng(-29.964658, -51.624919),
                                new LatLng(-29.964658, -51.624759),
                                new LatLng(-29.964464, -51.624759)
                        );

                PolygonOptions bFeminino_hall = new PolygonOptions()
                        .add(
                                new LatLng(-29.964426, -51.624759),
                                new LatLng(-29.964426, -51.624778),
                                new LatLng(-29.964444, -51.624799),
                                new LatLng(-29.964464, -51.624799),
                                new LatLng(-29.964464, -51.624759)
                        );


                PolygonOptions bMasculino_hall = new PolygonOptions()
                        .add(
                                new LatLng(-29.964426, -51.624678),
                                new LatLng(-29.964426, -51.624659),
                                new LatLng(-29.964444, -51.624638),
                                new LatLng(-29.964464, -51.624638),
                                new LatLng(-29.964464, -51.624678)
                        );

                PolygonOptions bloco_SalaProfessores = new PolygonOptions()
                        .add(
                                new LatLng(-29.964464, -51.624481),
                                new LatLng(-29.964497, -51.624481),
                                new LatLng(-29.964497, -51.624501),
                                new LatLng(-29.964517, -51.624501),
                                new LatLng(-29.964517, -51.624481),
                                new LatLng(-29.964551, -51.624481),
                                new LatLng(-29.964551, -51.624678),
                                new LatLng(-29.964464, -51.624678)
                        );

                PolygonOptions convivencia = new PolygonOptions()
                        .add(
                                new LatLng(-29.964551, -51.624560),
                                new LatLng(-29.964507, -51.624560),
                                new LatLng(-29.964507, -51.624501),
                                new LatLng(-29.964517, -51.624501),
                                new LatLng(-29.964517, -51.624481),
                                new LatLng(-29.964551, -51.624481)
                        );

                PolygonOptions sala_Estudo = new PolygonOptions()
                        .add(
                                new LatLng(-29.964464, -51.624481),
                                new LatLng(-29.964497, -51.624481),
                                new LatLng(-29.964497, -51.624501),
                                new LatLng(-29.964507, -51.624501),
                                new LatLng(-29.964507, -51.624560),
                                new LatLng(-29.964464, -51.624560)
                        );

                PolygonOptions sala_professoresRegulares = new PolygonOptions()
                        .add(
                                new LatLng(-29.964464, -51.624678),
                                new LatLng(-29.964551, -51.624678),
                                new LatLng(-29.964551, -51.624560),
                                new LatLng(-29.964464, -51.624560)
                        );

                PolygonOptions bloco_TI = new PolygonOptions()
                        .add(new LatLng(-29.964418, -51.624818),
                                new LatLng(-29.964341, -51.624726),
                                new LatLng(-29.964235, -51.624726),
                                new LatLng(-29.964222, -51.624745),
                                new LatLng(-29.964350, -51.624893)
                        );

                PolygonOptions bloco_BIO = new PolygonOptions()
                        .add(
                                new LatLng(-29.964341, -51.624696),
                                new LatLng(-29.964414, -51.624608),
                                new LatLng(-29.964352, -51.624536),
                                new LatLng(-29.964224, -51.624683),
                                new LatLng(-29.964243, -51.624696)
                        );

                PolygonOptions sala_bio = new PolygonOptions()
                        .add(
                                new LatLng(-29.964243, -51.624696),
                                new LatLng(-29.964224, -51.624683),
                                new LatLng(-29.964292, -51.624605),
                                new LatLng(-29.964346, -51.624665),
                                new LatLng(-29.964321, -51.624696)
                        );

                PolygonOptions sala_7 = new PolygonOptions()
                        .add(
                                new LatLng(-29.964386, -51.624576),
                                new LatLng(-29.964327, -51.624644),
                                new LatLng(-29.964292, -51.624605),
                                new LatLng(-29.964352, -51.624536)
                        );

                PolygonOptions sala_Cordenadores = new PolygonOptions()
                        .add(
                                new LatLng(-29.964364, -51.624668),
                                new LatLng(-29.964335, -51.624635),
                                new LatLng(-29.964386, -51.624576),
                                new LatLng(-29.964414, -51.624608)
                        );

                PolygonOptions bloco_18 = new PolygonOptions()
                        .add(
                                new LatLng(-29.963722, -51.624079),
                                new LatLng(-29.963616, -51.624079),
                                new LatLng(-29.963616, -51.624429),
                                new LatLng(-29.963722, -51.624429)
                        );


                PolygonOptions sala_1bloco_18 = new PolygonOptions()
                        .add(
                                new LatLng(-29.963722, -51.624359),
                                new LatLng(-29.963647, -51.624359),
                                new LatLng(-29.963647, -51.624429),
                                new LatLng(-29.963722, -51.624429)
                        );

                PolygonOptions sala_2bloco_18 = new PolygonOptions()
                        .add(
                                new LatLng(-29.963722, -51.624429),
                                new LatLng(-29.963722, -51.624289),
                                new LatLng(-29.963647, -51.624289),
                                new LatLng(-29.963647, -51.624429)
                        );

                PolygonOptions sala_3bloco_18 = new PolygonOptions()
                        .add(
                                new LatLng(-29.963722, -51.624289),
                                new LatLng(-29.963722, -51.624219),
                                new LatLng(-29.963647, -51.624219),
                                new LatLng(-29.963647, -51.624289)
                        );

                PolygonOptions sala_4bloco_18 = new PolygonOptions()
                        .add(
                                new LatLng(-29.963722, -51.624219),
                                new LatLng(-29.963722, -51.624149),
                                new LatLng(-29.963647, -51.624149),
                                new LatLng(-29.963647, -51.624219)
                        );

                PolygonOptions sala_5bloco_18 = new PolygonOptions()
                        .add(
                                new LatLng(-29.963722, -51.624149),
                                new LatLng(-29.963722, -51.624079),
                                new LatLng(-29.963647, -51.624079),
                                new LatLng(-29.963647, -51.624149)
                        );

                PolygonOptions bloco_Assistencia = new PolygonOptions()
                        .add(
                                new LatLng(-29.964087, -51.624311),
                                new LatLng(-29.964087, -51.624230),
                                new LatLng(-29.964200, -51.624230),
                                new LatLng(-29.964200, -51.624311)
                        );

                PolygonOptions assistencia = new PolygonOptions()
                        .add(
                                new LatLng(-29.964200, -51.624311),
                                new LatLng(-29.964200, -51.624230),
                                new LatLng(-29.964140, -51.624230),
                                new LatLng(-29.964140, -51.624260),
                                new LatLng(-29.964087, -51.624260),
                                new LatLng(-29.964087, -51.624280),
                                new LatLng(-29.964113, -51.624280),
                                new LatLng(-29.964113, -51.624295),
                                new LatLng(-29.964140, -51.624295),
                                new LatLng(-29.964140, -51.624310)
                        );

                PolygonOptions sala_orientadora = new PolygonOptions()
                        .add(
                                new LatLng(-29.964140, -51.624230),
                                new LatLng(-29.964140, -51.624260),
                                new LatLng(-29.964113, -51.624260),
                                new LatLng(-29.964113, -51.624230)
                        );

                PolygonOptions bUni1_assistencia = new PolygonOptions()
                        .add(
                                new LatLng(-29.964113, -51.624295),
                                new LatLng(-29.964113, -51.624310),
                                new LatLng(-29.964126, -51.624310),
                                new LatLng(-29.964126, -51.624295)
                        );

                PolygonOptions bUni2_assistencia = new PolygonOptions()
                        .add(
                                new LatLng(-29.964140, -51.624310),
                                new LatLng(-29.964140, -51.624295),
                                new LatLng(-29.964126, -51.624295),
                                new LatLng(-29.964126, -51.624310)
                        );

                PolygonOptions sala_aleatoria_assistencia = new PolygonOptions()
                        .add(
                                new LatLng(-29.964087, -51.624280),
                                new LatLng(-29.964087, -51.624310),
                                new LatLng(-29.964113, -51.624310),
                                new LatLng(-29.964113, -51.624280)
                        );

                PolygonOptions sala_especial = new PolygonOptions()
                        .add(
                                new LatLng(-29.964087, -51.624230),
                                new LatLng(-29.964087, -51.624260),
                                new LatLng(-29.964113, -51.624260),
                                new LatLng(-29.964113, -51.624230)
                        );

                PolygonOptions bloco_enfermaria = new PolygonOptions()
                        .add(
                                new LatLng(-29.964172, -51.624353),
                                new LatLng(-29.964087, -51.624353),
                                new LatLng(-29.964087, -51.624406),
                                new LatLng(-29.964172, -51.624406)
                        );

                PolygonOptions deposito_enfermaria= new PolygonOptions()
                        .add(
                                new LatLng(-29.964108, -51.624406),
                                new LatLng(-29.964108, -51.624394),
                                new LatLng(-29.964087, -51.624394),
                                new LatLng(-29.964087, -51.624406)
                        );

                PolygonOptions consultorio_enfermaria= new PolygonOptions()
                        .add(
                                new LatLng(-29.964087, -51.624353),
                                new LatLng(-29.964087, -51.624394),
                                new LatLng(-29.964115, -51.624394),
                                new LatLng(-29.964115, -51.624353)
                        );

                PolygonOptions enfermaria_enfermaria= new PolygonOptions()
                        .add(
                                new LatLng(-29.964115, -51.624394),
                                new LatLng(-29.964115, -51.624353),
                                new LatLng(-29.964143, -51.624353),
                                new LatLng(-29.964143, -51.624394)
                        );

                PolygonOptions bUni1_enfermaria= new PolygonOptions()
                        .add(
                                new LatLng(-29.964143, -51.624383),
                                new LatLng(-29.964160, -51.624383),
                                new LatLng(-29.964160, -51.624365),
                                new LatLng(-29.964155, -51.624365),
                                new LatLng(-29.964155, -51.624353),
                                new LatLng(-29.964143, -51.624353)
                        );

                PolygonOptions bUni2_enfermaria= new PolygonOptions()
                        .add(
                                new LatLng(-29.964160, -51.624373),
                                new LatLng(-29.964172, -51.624373),
                                new LatLng(-29.964172, -51.624353),
                                new LatLng(-29.964155, -51.624353),
                                new LatLng(-29.964155, -51.624365),
                                new LatLng(-29.964160, -51.624365)
                        );

                PolygonOptions sala_esperaEnfermaria = new PolygonOptions()
                        .add(
                                new LatLng(-29.964172, -51.624406),
                                new LatLng(-29.964108, -51.624406),
                                new LatLng(-29.964108, -51.624394),
                                new LatLng(-29.964143, -51.624394),
                                new LatLng(-29.964143, -51.624383),
                                new LatLng(-29.964160, -51.624383),
                                new LatLng(-29.964160, -51.624373),
                                new LatLng(-29.964172, -51.624373)
                        );

                PolygonOptions bloco_aquario = new PolygonOptions()
                        .add(
                                new LatLng(-29.964079, -51.624489),
                                new LatLng(-29.964131, -51.624489),
                                new LatLng(-29.964131, -51.624541),
                                new LatLng(-29.964079, -51.624541)
                        );

                PolygonOptions bloco_Cantina = new PolygonOptions()
                        .add(
                                new LatLng(-29.964798, -51.624724),
                                new LatLng(-29.964582, -51.624724),
                                new LatLng(-29.964582, -51.624497),
                                new LatLng(-29.964798, -51.624497)
                        );

                PolygonOptions cantina = new PolygonOptions()
                        .add(
                                new LatLng(-29.964798, -51.624649),
                                new LatLng(-29.964798, -51.624572),
                                new LatLng(-29.964740, -51.624572),
                                new LatLng(-29.964740, -51.624522),
                                new LatLng(-29.964700, -51.624522),
                                new LatLng(-29.964685, -51.624542),
                                new LatLng(-29.964685, -51.624679),
                                new LatLng(-29.964700, -51.624699),
                                new LatLng(-29.964740, -51.624699),
                                new LatLng(-29.964740, -51.624649)
                        );

                PolygonOptions bFem_Cantina = new PolygonOptions()
                        .add(
                                new LatLng(-29.964798, -51.624724),
                                new LatLng(-29.964798, -51.624649),
                                new LatLng(-29.964755, -51.624649),
                                new LatLng(-29.964755, -51.624724)
                        );

                PolygonOptions bMasc_cantina = new PolygonOptions()
                        .add(
                                new LatLng(-29.964798, -51.624497),
                                new LatLng(-29.964755, -51.624497),
                                new LatLng(-29.964755, -51.624572),
                                new LatLng(-29.964798, -51.624572)
                        );

                PolygonOptions perimetroIF = new PolygonOptions()
                        .add(
                                new LatLng(-29.965967, -51.625700),
                                new LatLng(-29.965292, -51.623965),
                                new LatLng(-29.962481, -51.623921),
                                new LatLng(-29.962470, -51.624698),
                                new LatLng(-29.963849, -51.625258),
                                new LatLng(-29.964047, -51.625120),
                                new LatLng(-29.964254, -51.625357),
                                new LatLng(-29.964167, -51.625450)
                        );

                PolygonOptions bloco_mct = new PolygonOptions()
                        .add(
                                new LatLng(-29.963777, -51.624380),
                                new LatLng(-29.963777, -51.624256),
                                new LatLng(-29.963843, -51.624256),
                                new LatLng(-29.963863, -51.624233),
                                new LatLng(-29.963863, -51.624166),
                                new LatLng(-29.963963, -51.624166),
                                new LatLng(-29.963963, -51.624233),
                                new LatLng(-29.963982, -51.624256),
                                new LatLng(-29.964046, -51.624256),
                                new LatLng(-29.964046, -51.624380),
                                new LatLng(-29.963987, -51.624380),
                                new LatLng(-29.963956, -51.624347),
                                new LatLng(-29.963936, -51.624369),
                                new LatLng(-29.963963, -51.624399),
                                new LatLng(-29.963963, -51.624465),
                                new LatLng(-29.963863, -51.624465),
                                new LatLng(-29.963863, -51.624399),
                                new LatLng(-29.963883, -51.624368),
                                new LatLng(-29.963865, -51.624345),
                                new LatLng(-29.963839, -51.624380)
                        );

                PolygonOptions lab_cnc = new PolygonOptions()
                        .add(
                                new LatLng(-29.963913, -51.624465),
                                new LatLng(-29.963913, -51.624368),
                                new LatLng(-29.963936, -51.624369),
                                new LatLng(-29.963963, -51.624399),
                                new LatLng(-29.963963, -51.624465)
                        );

                PolygonOptions lab_metrologia = new PolygonOptions()
                        .add(
                                new LatLng(-29.963913, -51.624465),
                                new LatLng(-29.963913, -51.624368),
                                new LatLng(-29.963883, -51.624368),
                                new LatLng(-29.963863, -51.624399),
                                new LatLng(-29.963863, -51.624465)
                        );

                PolygonOptions lab_InfInd= new PolygonOptions()
                        .add(
                                new LatLng(-29.963956, -51.624318),
                                new LatLng(-29.964046, -51.624318),
                                new LatLng(-29.964046, -51.624380),
                                new LatLng(-29.963987, -51.624380),
                                new LatLng(-29.963956, -51.624347)
                        );

                PolygonOptions manutencaoHidraulica= new PolygonOptions()
                        .add(
                                new LatLng(-29.963956, -51.624318),
                                new LatLng(-29.963956, -51.624285),
                                new LatLng(-29.963982, -51.624256),
                                new LatLng(-29.964046, -51.624256),
                                new LatLng(-29.964046, -51.624318)
                        );

                PolygonOptions lab_oficinaFabricacaoMecanica= new PolygonOptions()
                        .add(
                                new LatLng(-29.963865, -51.624345),
                                new LatLng(-29.963839, -51.624380),
                                new LatLng(-29.963777, -51.624380),
                                new LatLng(-29.963777, -51.624256),
                                new LatLng(-29.963843, -51.624256),
                                new LatLng(-29.963868, -51.624285)
                        );

                PolygonOptions bFemBloco10= new PolygonOptions()
                        .add(
                                new LatLng(-29.963888, -51.624262),
                                new LatLng(-29.963863, -51.624233),
                                new LatLng(-29.963843, -51.624256),
                                new LatLng(-29.963868, -51.624285)
                        );

                PolygonOptions bMascBloco10= new PolygonOptions()
                        .add(
                                new LatLng(-29.963956, -51.624285),
                                new LatLng(-29.963982, -51.624256),
                                new LatLng(-29.963963, -51.624233),
                                new LatLng(-29.963937, -51.624262)
                        );

                PolygonOptions lab_manutencao_solda= new PolygonOptions()
                        .add(
                                new LatLng(-29.963937, -51.624262),
                                new LatLng(-29.963963, -51.624233),
                                new LatLng(-29.963963, -51.624166),
                                new LatLng(-29.963913, -51.624166),
                                new LatLng(-29.963913, -51.624262)
                        );

                PolygonOptions lab_almox_ferramentaria= new PolygonOptions()
                        .add(
                                new LatLng(-29.963913, -51.624262),
                                new LatLng(-29.963913, -51.624166),
                                new LatLng(-29.963863, -51.624166),
                                new LatLng(-29.963863, -51.624233),
                                new LatLng(-29.963888, -51.624262)
                        );

                PolygonOptions quadra = new PolygonOptions()
                        .add(
                                new LatLng(-29.963037, -51.624369),
                                new LatLng(-29.963043, -51.624087),
                                new LatLng(-29.962612, -51.624079),
                                new LatLng(-29.962604, -51.624353)
                        );

                PolygonOptions bloco_biblioteca = new PolygonOptions()
                        .add(
                                new LatLng(-29.964909, -51.624800),
                                new LatLng(-29.964781, -51.624798),
                                new LatLng(-29.964708, -51.624888),
                                new LatLng(-29.964760, -51.624952),
                                new LatLng(-29.964777, -51.624952),
                                new LatLng(-29.964777, -51.625000),
                                new LatLng(-29.964849, -51.625000),
                                new LatLng(-29.964876, -51.624990),
                                new LatLng(-29.964876, -51.625039),
                                new LatLng(-29.964890, -51.625039),
                                new LatLng(-29.964890, -51.625073),
                                new LatLng(-29.964933, -51.625073),
                                new LatLng(-29.964933, -51.624987),
                                new LatLng(-29.964916, -51.624987),
                                new LatLng(-29.964916, -51.624952),
                                new LatLng(-29.964876, -51.624952),
                                new LatLng(-29.964876, -51.624922),
                                new LatLng(-29.964909, -51.624922)
                        );

                PolygonOptions biblioteca = new PolygonOptions()
                        .add(
                                new LatLng(-29.964909, -51.624800),
                                new LatLng(-29.964781, -51.624798),
                                new LatLng(-29.964708, -51.624888),
                                new LatLng(-29.964760, -51.624952),
                                new LatLng(-29.964777, -51.624952),
                                new LatLng(-29.964777, -51.625000),
                                new LatLng(-29.964849, -51.625000),
                                new LatLng(-29.964849, -51.624952),
                                new LatLng(-29.964820, -51.624952),
                                new LatLng(-29.964820, -51.624922),
                                new LatLng(-29.964909, -51.624922)
                        );

                PolygonOptions cozinha_almoxarifado = new PolygonOptions()
                        .add(
                                new LatLng(-29.964849, -51.625000),
                                new LatLng(-29.964876, -51.624990),
                                new LatLng(-29.964916, -51.624987),
                                new LatLng(-29.964916, -51.624952),
                                new LatLng(-29.964849, -51.624952)
                        );

                PolygonOptions almoxarifado_biblioteca = new PolygonOptions()
                        .add(
                                new LatLng(-29.964876, -51.624990),
                                new LatLng(-29.964876, -51.625039),
                                new LatLng(-29.964890, -51.625039),
                                new LatLng(-29.964890, -51.625073),
                                new LatLng(-29.964933, -51.625073),
                                new LatLng(-29.964933, -51.624987),
                                new LatLng(-29.964916, -51.624987)
                        );

                PolygonOptions adm_biblioteca = new PolygonOptions()
                        .add(
                                new LatLng(-29.964820, -51.624952),
                                new LatLng(-29.964820, -51.624922),
                                new LatLng(-29.964876, -51.624922),
                                new LatLng(-29.964876, -51.624952)
                        );

                PolygonOptions administracao = new PolygonOptions()
                        .add(
                                new LatLng(-29.964237, -51.624863),
                                new LatLng(-29.964134, -51.624737),
                                new LatLng(-29.964110, -51.624761),
                                new LatLng(-29.964077, -51.624725),
                                new LatLng(-29.964014, -51.624725),
                                new LatLng(-29.963984, -51.624759),
                                new LatLng(-29.963960, -51.624728),
                                new LatLng(-29.963842, -51.624863),
                                new LatLng(-29.963904, -51.624937),
                                new LatLng(-29.964021, -51.624807),
                                new LatLng(-29.964072, -51.624805),
                                new LatLng(-29.964175, -51.624929)
                        );

                PolygonOptions portaria = new PolygonOptions()
                        .add(
                                new LatLng(-29.964209, -51.625219),
                                new LatLng(-29.964157, -51.625219),
                                new LatLng(-29.964160, -51.625278),
                                new LatLng(-29.964205, -51.625281)
                        );

                Polygon polygonBloco17 = mMap.addPolygon(bloco_17);
                Polygon polygonBloco10 = mMap.addPolygon(bloco_10);
                Polygon polygonAuditorio = mMap.addPolygon(auditorio);
                Polygon polygonBlocoTI = mMap.addPolygon(bloco_TI);
                Polygon polygonBlocoBIO = mMap.addPolygon(bloco_BIO);
                Polygon polygonBloco18 = mMap.addPolygon(bloco_18);
                Polygon polygonBlocoAssistencia = mMap.addPolygon(bloco_Assistencia);
                Polygon polygonBlocoEnfermaria = mMap.addPolygon(bloco_enfermaria);
                Polygon polygonBlocoAquario = mMap.addPolygon(bloco_aquario);
                Polygon polygonBlocoCantina = mMap.addPolygon(bloco_Cantina);
                Polygon polygonProfessores= mMap.addPolygon(bloco_SalaProfessores);
                Polygon polygonPerimetro= mMap.addPolygon(perimetroIF);
                Polygon polygonBlocoMCT= mMap.addPolygon(bloco_mct);
                Polygon polygonBlocoArtes= mMap.addPolygon(bloco_sala_artes);
                Polygon polygonQuadra= mMap.addPolygon(quadra);
                Polygon polygonBiblioteca= mMap.addPolygon(bloco_biblioteca);
                Polygon polygonAdministracao= mMap.addPolygon(administracao);
                Polygon polygonPortaria= mMap.addPolygon(portaria);
                Polygon polygonsSala1= mMap.addPolygon(sala_1);
                Polygon polygonsSala2= mMap.addPolygon(sala_2);
                Polygon polygonsSala3= mMap.addPolygon(sala_3);
                Polygon polygonsSala4= mMap.addPolygon(sala_4);
                Polygon polygonsSala5= mMap.addPolygon(sala_5);
                Polygon polygonsGremio= mMap.addPolygon(gremio);
                Polygon polygonsLabEletricidade1= mMap.addPolygon(lab_eletricidade_1);
                Polygon polygonsSalaArtes= mMap.addPolygon(sala_artes);
                Polygon polygonsLabInfCAD= mMap.addPolygon(lab_informatica_CAD);
                Polygon polygonsLabInfCAD2= mMap.addPolygon(lab_informatica_CAD2);
                Polygon polygonsEletronica= mMap.addPolygon(eletronica);
                Polygon polygonsMiniAuditorio= mMap.addPolygon(miniAuditorio);
                Polygon polygonsBfeBloco8= mMap.addPolygon(bFeminino_bloco8);
                Polygon polygonsBmaBloco8= mMap.addPolygon(bMasculino_bloco8);
                Polygon polygonsLabEletricidadeNSEI= mMap.addPolygon(lab_eletricidade_nsei);
                Polygon polygonsAlmoxarifadoEletronica= mMap.addPolygon(almoxarifado_eletronica);
                Polygon polygonsBfeHall= mMap.addPolygon(bFeminino_hall);
                Polygon polygonsBmaHall= mMap.addPolygon(bMasculino_hall);
                Polygon polygonsSalaProfessoresRegulares= mMap.addPolygon(sala_professoresRegulares);
                Polygon polygonsConvivencia = mMap.addPolygon(convivencia);
                Polygon polygonsSalaDeEstudo = mMap.addPolygon(sala_Estudo);
                Polygon polygonsSalaBIO = mMap.addPolygon(sala_bio);
                Polygon polygonsSala7 = mMap.addPolygon(sala_7);
                Polygon polygonsSalaCordenadores = mMap.addPolygon(sala_Cordenadores);
                Polygon polygonsSala1bloco18= mMap.addPolygon(sala_1bloco_18);
                Polygon polygonsSala2bloco18= mMap.addPolygon(sala_2bloco_18);
                Polygon polygonsSala3bloco18= mMap.addPolygon(sala_3bloco_18);
                Polygon polygonsSala4bloco18= mMap.addPolygon(sala_4bloco_18);
                Polygon polygonsSala5bloco18= mMap.addPolygon(sala_5bloco_18);
                Polygon polygonsBmascCantina= mMap.addPolygon(bMasc_cantina);
                Polygon polygonsBfemCantina= mMap.addPolygon(bFem_Cantina);
                Polygon polygonsCantina= mMap.addPolygon(cantina);
                Polygon polygonsAssistencia= mMap.addPolygon(assistencia);
                Polygon polygonsSalaOrientadora= mMap.addPolygon(sala_orientadora);
                Polygon polygonsSalaEspecial= mMap.addPolygon(sala_especial);
                Polygon polygonsSalaAleatoriaBlocoAssistencia= mMap.addPolygon(sala_aleatoria_assistencia);
                Polygon polygonsBuni1Assistencia= mMap.addPolygon(bUni1_assistencia);
                Polygon polygonsBuni2Assistencia= mMap.addPolygon(bUni2_assistencia);
                Polygon polygonsSalaEsperaEnfermaria= mMap.addPolygon(sala_esperaEnfermaria);
                Polygon polygonsDepositoEnfermaria= mMap.addPolygon(deposito_enfermaria);
                Polygon polygonsConsultorioEnfermaria= mMap.addPolygon(consultorio_enfermaria);
                Polygon polygonsEnfermariaEnfermaria= mMap.addPolygon(enfermaria_enfermaria);
                Polygon polygonsBuni1Enfermaria= mMap.addPolygon(bUni1_enfermaria);
                Polygon polygonsBuni2Enfermaria= mMap.addPolygon(bUni2_enfermaria);
                Polygon polygonsBiblioteca= mMap.addPolygon(biblioteca);
                Polygon polygonsAdmBiblioteca= mMap.addPolygon(adm_biblioteca);
                Polygon polygonsAlmoxarifadoBiblioteca= mMap.addPolygon(almoxarifado_biblioteca);
                Polygon polygonsCozinhaAlmoxarifado= mMap.addPolygon(cozinha_almoxarifado);
                Polygon polygonsLabCnc= mMap.addPolygon(lab_cnc);
                Polygon polygonsLabMetrologia= mMap.addPolygon(lab_metrologia);
                Polygon polygonsLabInfInd= mMap.addPolygon(lab_InfInd);
                Polygon polygonsManutencaoHidraulica= mMap.addPolygon(manutencaoHidraulica);
                Polygon polygonsBMascBloco10= mMap.addPolygon(bMascBloco10);
                Polygon polygonslabManutencaoSolda= mMap.addPolygon(lab_manutencao_solda);
                Polygon polygonslabAlmoxFerramentaria= mMap.addPolygon(lab_almox_ferramentaria);
                Polygon polygonsbFemBloco10= mMap.addPolygon(bFemBloco10);
                Polygon polygonsbLabFabricacaoMecanica= mMap.addPolygon(lab_oficinaFabricacaoMecanica);

                /* mMap.setOnPolygonClickListener(new GoogleMap.OnPolygonClickListener() {
                    @Override
                    public void onPolygonClick(Polygon polygon) {

                    }
                }); */
                mMap.moveCamera(location);
                mMap.animateCamera(zoom,300,null);
            }
        });

        return root;
    }
}