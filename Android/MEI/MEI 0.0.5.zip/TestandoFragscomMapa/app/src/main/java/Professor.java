public class Professor extends Pessoa {

    private String suap;
    private String[] turmas;

    Professor(String nome, String email, String senha) {
        super(nome, email, senha);
    }

   // private void reservaChave(Chave chave){
     //   this.chave = chave;
   // }

}
