package com.example.testandofragscommapa.ui.dashboard;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.testandofragscommapa.R;

public class DashboardFragment extends Fragment {

    private DashboardViewModel dashboardViewModel;
    private ImageButton materia;
    private ImageButton turma;
    private ImageButton professor;
    private ImageButton sala;

    private  int CONTEXTO = 0;

    public View onCreateView(@NonNull final LayoutInflater inflater,
                             final ViewGroup container, Bundle savedInstanceState) {
        dashboardViewModel = ViewModelProviders.of(this).get(DashboardViewModel.class);
        final FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        fragmentTransaction.detach(this).attach(this);
        if(CONTEXTO == 0) {
            View root = inflater.inflate(R.layout.fragment_dashboard, container, false);

            materia = root.findViewById(R.id.imageButtonMateria);
            turma = root.findViewById(R.id.imageButtonTurma);
            professor = root.findViewById(R.id.imageButtonProfessor);
            sala = root.findViewById(R.id.imageButtonSala);

            materia.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    CONTEXTO=1;
                    fragmentTransaction.commit();
                }
            });
            turma.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    CONTEXTO=2;
                    fragmentTransaction.commit();
                }
            });
            professor.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    CONTEXTO=3;
                    fragmentTransaction.commit();
                }
            });
            sala.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    CONTEXTO=4;
                    fragmentTransaction.commit();
                }
            });

            return root;
        } else {
            if(CONTEXTO==1) {
                View root = inflater.inflate(R.layout.fragment_materia, container, false);
                return root;
            }else{
                if (CONTEXTO==2){
                    View root = inflater.inflate(R.layout.fragment_turma, container, false);
                    return root;
                }else{
                    if (CONTEXTO==3){
                        View root = inflater.inflate(R.layout.fragment_professor, container, false);
                        return root;
                    }else{
                        View root = inflater.inflate(R.layout.fragment_sala, container, false);
                        return root;
                    }
                }
            }





        }


    }


}