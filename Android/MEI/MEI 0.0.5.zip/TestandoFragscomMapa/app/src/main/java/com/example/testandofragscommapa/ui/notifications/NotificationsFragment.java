package com.example.testandofragscommapa.ui.notifications;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.testandofragscommapa.CadastroActivity;
import com.example.testandofragscommapa.R;
import com.example.testandofragscommapa.SenhaActivity;

public class NotificationsFragment extends Fragment {

    private NotificationsViewModel notificationsViewModel;
    public EditText login;
    private EditText pass;
    private Button enviar;




    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        notificationsViewModel = ViewModelProviders.of(this).get(NotificationsViewModel.class);

        final SharedPreferences sessao = getContext().getSharedPreferences("dados_login",Context.MODE_PRIVATE);

        final FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        fragmentTransaction.detach(this).attach(this);

        int idLogado = sessao.getInt("id",-1);
        Log.d("debug login", "mensagem id logado"+idLogado);
        if(idLogado == -1) {

            View root = inflater.inflate(R.layout.fragment_notifications, container, false);

            TextView esquecerSenha = root.findViewById(R.id.textView_EsquecerSenha);
            TextView cadastro = root.findViewById(R.id.textView_Cadastrar);
            login = root.findViewById(R.id.editText_Usuario);
            pass = root.findViewById(R.id.editText_Senha);
            enviar = root.findViewById(R.id.button_entrar);



            esquecerSenha.setOnClickListener(new View.OnClickListener(){

                public void onClick(View v){
                    Intent i = new Intent(getContext(), SenhaActivity.class);
                    startActivity(i);
                }
            });

            cadastro.setOnClickListener(new View.OnClickListener(){

                public void onClick(View v){
                    Intent i = new Intent(getContext(), CadastroActivity.class);
                    startActivity(i);
                }
            });


            enviar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    RequestQueue filaEnviadoraDeMensagens = Volley.newRequestQueue(getContext());

                    String urlServidor = "http://192.168.31.17/MEI/EfetuarLogin.php";


                    urlServidor = urlServidor + "?login=" + login.getText().toString();
                    urlServidor = urlServidor + "&pass=" + pass.getText().toString();
                    Log.d("TAG_AAAA",
                            "   " + urlServidor);

                    StringRequest requisicao = new StringRequest(
                            Request.Method.GET, // 1 - Método usado para enviar mensagem
                            urlServidor,        // 2 - Endereço do servidor
                            new Response.Listener<String>() { // 3 - Objeto para tratar resposta
                                @Override
                                public void onResponse(String response) {

                                    Log.e("TAG_EXEMPLO",
                                            "   " + response);
                                    String id = response;
                                    // exibe o resultado na tela usando Toast
                                    Toast.makeText(
                                            getContext(),
                                            "id = " + response,
                                            Toast.LENGTH_LONG).show();

                                     // gravar na sessao
                                    SharedPreferences.Editor edit = sessao.edit();
                                    edit.putInt("id",1);
                                    edit.apply();
                                    // refresh da tela
                                    fragmentTransaction.commit();

                                }


                            },
                            new Response.ErrorListener() { // 4 - Objeto para tratar erro
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    // exibe o erro na tela e nos Logs
                                    Toast.makeText(
                                            getContext(),
                                            "Erro: " + error,
                                            Toast.LENGTH_LONG).show();
                                    // log de erro no LogCat
                                    Log.e("TAG_EXEMPLO",
                                            "Erro encontrado ao tentar enviar mensagem", error);
                                }
                            });


                    // envia a mensagem ao servidor
                    filaEnviadoraDeMensagens.add(requisicao);
                }
            });
            return root;
        } else {


            View root = inflater.inflate(R.layout.fragment_reserva_de_chaves, container, false);
            Button deslogar = root.findViewById(R.id.button);

            deslogar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final SharedPreferences sessao = getContext().getSharedPreferences("dados_login",Context.MODE_PRIVATE);
                    SharedPreferences.Editor edit = sessao.edit();
                    edit.putInt("id",-1);
                    edit.apply();
                    fragmentTransaction.commit();
                }
            });
            return root;
        }
    }



    public void desloga(){

    }

}