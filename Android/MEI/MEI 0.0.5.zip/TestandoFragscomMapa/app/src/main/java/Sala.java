public class Sala {
    private String bloco;
    private String nome;



    Sala(String bloco, String nome){
        this.bloco = bloco;
        this.nome = nome;


    }
}
