public class Materia {
    private String nome;
    private Professor professores[];
    private Sala salas[];
}
